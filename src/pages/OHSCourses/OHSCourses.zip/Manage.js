import React, { useEffect, useState } from "react";
import { 
  Breadcrumb, 
  Container, 
  Row, 
  Col, 
  Form, 
  Button, 
  Modal, 
  Alert,
  Card,
  Image 
} from "react-bootstrap";
import axios from "axios";
import { toast } from "react-toastify";
import { useSelector } from "react-redux";
import { MdDelete, MdEdit, MdAdd } from "react-icons/md";

const DEFAULT_DESCRIPTION = "This course is designed to enhance your skills and knowledge in occupational health & safety.";
const DEFAULT_CONTACT = {
  name: "OHS Academy",
  email: "ohsacademy1@gmail.com",
  phone: "03429090753",
  address: "Main bazar sher ghar khattak plaza top floor peshawar",
};

export default function OhsCourseManage() {
  const token = useSelector((state) => state.auth.token);
  const API_BASE = process.env.REACT_APP_BASE_ADMIN_API;

  const [role, setRole] = useState(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const [description, setDescription] = useState(DEFAULT_DESCRIPTION);
  const [courses, setCourses] = useState([]);           // ← Ab objects honge
  const [contact, setContact] = useState(DEFAULT_CONTACT);

  // Add New Course
  const [newCourseName, setNewCourseName] = useState("");
  const [newCourseImageFile, setNewCourseImageFile] = useState(null);
  const [newCourseImagePreview, setNewCourseImagePreview] = useState("");

  // Edit
  const [showEditModal, setShowEditModal] = useState(false);
  const [editIndex, setEditIndex] = useState(null);
  const [editValue, setEditValue] = useState("");
  const [editImageFile, setEditImageFile] = useState(null);
  const [editImagePreview, setEditImagePreview] = useState("");

  const [search, setSearch] = useState("");
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteIndex, setDeleteIndex] = useState(null);

  // Filtered Courses
  const filteredCourses = courses.filter((c) =>
    c.name?.toLowerCase().includes(search.toLowerCase().trim())
  );

  const fetchInitialData = async () => {
    if (!token) return;
    setLoading(true);
    try {
      const [userRes, configRes] = await Promise.all([
        axios.get(`${API_BASE}/auth/userDetails`, { headers: { Authorization: `Bearer ${token}` } }),
        axios.get(`${API_BASE}/admin/ohs-courses`, { headers: { Authorization: `Bearer ${token}` } }),
      ]);

      setRole(userRes.data?.user?.role ?? null);
      setDescription(configRes.data?.description || DEFAULT_DESCRIPTION);
      setContact({
        name: configRes.data?.name || DEFAULT_CONTACT.name,
        email: configRes.data?.email || DEFAULT_CONTACT.email,
        phone: configRes.data?.phone || DEFAULT_CONTACT.phone,
        address: configRes.data?.address || DEFAULT_CONTACT.address,
      });

      let loadedCourses = Array.isArray(configRes.data?.courses) ? configRes.data.courses : [];

      // Backward compatibility: agar string array aa raha hai
      if (loadedCourses.length && typeof loadedCourses[0] === "string") {
        loadedCourses = loadedCourses.map(name => ({ name: String(name).trim(), image: "" }));
      }

      setCourses(loadedCourses);
    } catch (err) {
      toast.error("Failed to load OHS config");
      setCourses([]);
    } finally {
      setLoading(false);
    }
  };

  // ==================== FIXED PERSIST CONFIG (Image Binary) ====================
  const persistConfig = async (nextDesc, nextCourses, nextContact = contact, imageFile = null) => {
    setSaving(true);
    try {
      const formData = new FormData();

      formData.append("description", String(nextDesc || ""));
      formData.append("name", String(nextContact.name || ""));
      formData.append("email", String(nextContact.email || ""));
      formData.append("phone", String(nextContact.phone || ""));
      formData.append("address", String(nextContact.address || ""));
      formData.append("courses", JSON.stringify(nextCourses || []));

      if (imageFile) {
        formData.append("courseImage", imageFile);
        formData.append("imageIndex", String(nextCourses.length - 1));
      }

      await axios.put(`${API_BASE}/admin/ohs-courses`, formData, {
        headers: { Authorization: `Bearer ${token}` }
      });

      setDescription(nextDesc);
      setCourses(nextCourses);
      setContact(nextContact);
      toast.success("OHS courses updated successfully");
    } catch (err) {
      console.error(err.response?.data || err);
      toast.error(err.response?.data?.message || "Update failed");
    } finally {
      setSaving(false);
    }
  };

  useEffect(() => {
    fetchInitialData();
  }, [token]);

  const isTeacher = role === "teacher";

  const handleNewImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setNewCourseImageFile(file);
      setNewCourseImagePreview(URL.createObjectURL(file));
    }
  };

  const addCourse = async () => {
    const name = newCourseName.trim();
    if (!name) return toast.error("Course name is required");

    if (courses.some(c => c.name.toLowerCase() === name.toLowerCase())) {
      return toast.error("This course already exists");
    }

    const newCourse = { name, image: "" };
    const updatedCourses = [newCourse, ...courses];

    await persistConfig(description, updatedCourses, contact, newCourseImageFile);

    setNewCourseName("");
    setNewCourseImageFile(null);
    setNewCourseImagePreview("");
  };

  const startEdit = (idx) => {
    const course = courses[idx];
    setEditIndex(idx);
    setEditValue(course.name);
    setEditImagePreview(course.image || "");
    setEditImageFile(null);
    setShowEditModal(true);
  };

  const handleEditImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setEditImageFile(file);
      setEditImagePreview(URL.createObjectURL(file));
    }
  };

  const saveEdit = async () => {
    const nextName = editValue.trim();
    if (!nextName) return toast.error("Course name cannot be empty");

    const nextCourses = [...courses];
    nextCourses[editIndex] = { ...nextCourses[editIndex], name: nextName };

    if (nextCourses.some((c, i) => i !== editIndex && c.name.toLowerCase() === nextName.toLowerCase())) {
      return toast.error("Another course with same name already exists");
    }

    setShowEditModal(false);
    await persistConfig(description, nextCourses, contact, editImageFile);
  };

  const requestDelete = (idx) => {
    setDeleteIndex(idx);
    setShowDeleteModal(true);
  };

  const confirmDelete = async () => {
    if (courses.length <= 1) return toast.error("At least one course should remain");
    const nextCourses = courses.filter((_, i) => i !== deleteIndex);
    setShowDeleteModal(false);
    await persistConfig(description, nextCourses, contact);
  };

  return (
    <Container>
      <Breadcrumb>
        <Breadcrumb.Item href="/dashboard">Dashboard</Breadcrumb.Item>
        <Breadcrumb.Item active>OHS Courses Manage</Breadcrumb.Item>
      </Breadcrumb>

      <h2 className="mb-4 fw-semibold name_heading">OHS Academy - Manage Courses</h2>

      {loading ? (
        <div className="text-center py-5">
          <div className="spinner-border text-primary" role="status" />
          <p className="mt-2">Loading courses...</p>
        </div>
      ) : (
        <>
          {!isTeacher && (
            <Alert variant="warning" className="mb-4">
              <strong>Note:</strong> Only teachers can add, edit or delete courses.
            </Alert>
          )}

          <Row className="g-4 mb-5">
            {/* Add New Course Card */}
            <Col lg={5}>
              <Card className="h-100 shadow-sm" style={{ backgroundImage: "url('/newcourse.jpg')", backgroundSize: "cover", backgroundPosition: "center" }}>
                <Card.Body style={{ backgroundColor: "rgba(255,255,255,0.85)", borderRadius: "8px" }}>
                  <Card.Title className="d-flex align-items-center gap-2">
                    <MdAdd size={24} /> Add New Course
                  </Card.Title>

                  <Form className="mt-3" onSubmit={(e) => { e.preventDefault(); addCourse(); }}>
                    <Form.Group className="mb-3">
                      <Form.Label>Course Name</Form.Label>
                      <Form.Control
                        placeholder="Enter course name (e.g. NEBOSH)"
                        value={newCourseName}
                        onChange={(e) => setNewCourseName(e.target.value)}
                        disabled={!isTeacher || saving}
                      />
                    </Form.Group>

                    <Form.Group className="mb-3">
                      <Form.Label>Course Image (Optional)</Form.Label>
                      <Form.Control 
                        type="file" 
                        accept="image/*" 
                        onChange={handleNewImageChange}
                        disabled={!isTeacher || saving}
                      />
                      {newCourseImagePreview && (
                        <Image src={newCourseImagePreview} fluid rounded className="mt-2" style={{ maxHeight: "160px" }} />
                      )}
                    </Form.Group>

                    <Button variant="success" className="w-100" onClick={addCourse} disabled={!isTeacher || saving || !newCourseName.trim()}>
                      Add Course
                    </Button>
                  </Form>
                </Card.Body>
              </Card>
            </Col>

            {/* Description Card - Same as before */}
            <Col lg={7}>
              <Card className="h-100 shadow-sm" style={{ background: "url('/more1.jpg')", backgroundSize: "cover", backgroundPosition: "center" }}>
                <Card.Body style={{ backgroundColor: "rgba(255,255,255,0.9)", borderRadius: "8px" }}>
                  <Card.Title>Course Information (Shared for all courses)</Card.Title>

                  <Row className="mt-3">
                    <Col md={6}>
                      <Form.Label className="mb-1">Name</Form.Label>
                      <Form.Control value={contact.name} onChange={(e) => setContact(p => ({...p, name: e.target.value}))} disabled={!isTeacher || saving} />
                    </Col>
                    <Col md={6}>
                      <Form.Label className="mb-1">Email</Form.Label>
                      <Form.Control type="email" value={contact.email} onChange={(e) => setContact(p => ({...p, email: e.target.value}))} disabled={!isTeacher || saving} />
                    </Col>
                  </Row>

                  <Row className="mt-3">
                    <Col md={6}>
                      <Form.Label className="mb-1">Phone</Form.Label>
                      <Form.Control value={contact.phone} onChange={(e) => setContact(p => ({...p, phone: e.target.value}))} disabled={!isTeacher || saving} />
                    </Col>
                    <Col md={6}>
                      <Form.Label className="mb-1">Address</Form.Label>
                      <Form.Control value={contact.address} onChange={(e) => setContact(p => ({...p, address: e.target.value}))} disabled={!isTeacher || saving} />
                    </Col>
                  </Row>

                  <Form.Group className="mt-3">
                    <Form.Label className="mb-1">Description</Form.Label>
                    <Form.Control as="textarea" rows={5} value={description} onChange={(e) => setDescription(e.target.value)} disabled={!isTeacher || saving} />
                  </Form.Group>

                  <Button variant="primary" className="mt-3" onClick={() => persistConfig(description, courses, contact)} disabled={!isTeacher || saving}>
                    {saving ? "Saving Changes..." : "Save Description"}
                  </Button>
                </Card.Body>
              </Card>
            </Col>
          </Row>

          {/* Courses List with Image + Watermark */}
          <Card className="shadow-sm">
            <Card.Header className="bg-light py-3">
              <div className="d-flex justify-content-between align-items-center">
                <h5 className="mb-0 fw-semibold">All Courses ({filteredCourses.length})</h5>
                <Form.Control
                  type="text"
                  placeholder="Search course..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  style={{ width: "200px" }}
                />
              </div>
            </Card.Header>

            <Card.Body style={{ maxHeight: "520px", overflowY: "auto" }}>
              <Row className="g-3">
                {filteredCourses.length > 0 ? (
                  filteredCourses.map((course, idx) => {
                    const originalIndex = courses.findIndex(c => c.name === course.name);
                    const imageSrc = course.image || "/newcourse.jpg";

                    return (
                      <Col key={course.name} md={6} lg={4}>
                        <Card className="h-100 position-relative overflow-hidden shadow-sm border-0">
                          <div className="position-relative">
                            <img 
                              src={imageSrc} 
                              alt={course.name}
                              style={{ height: "210px", width: "100%", objectFit: "cover" }}
                              onError={(e) => e.target.src = "/newcourse.jpg"}
                            />
                            <span style={{
                              position: "absolute",
                              top: "10px",
                              right: "15px",
                              fontSize: "70px",
                              fontWeight: "bold",
                              color: "rgba(255, 193, 7, 0.25)",
                              pointerEvents: "none",
                              zIndex: 2,
                            }}>
                              {originalIndex + 1}
                            </span>
                          </div>

                          <Card.Body>
                            <Card.Title className="fs-6 mb-3">{course.name}</Card.Title>
                            <div className="d-flex gap-2">
                              <Button variant="outline-primary" size="sm" onClick={() => startEdit(originalIndex)} disabled={!isTeacher || saving}>
                                <MdEdit /> Edit
                              </Button>
                              <Button variant="outline-danger" size="sm" onClick={() => requestDelete(originalIndex)} disabled={!isTeacher || saving}>
                                <MdDelete /> Delete
                              </Button>
                            </div>
                          </Card.Body>
                        </Card>
                      </Col>
                    );
                  })
                ) : (
                  <Col xs={12} className="text-center text-muted py-5">
                    No courses found
                  </Col>
                )}
              </Row>
            </Card.Body>
          </Card>
        </>
      )}

      {/* Edit Modal */}
      <Modal show={showEditModal} onHide={() => setShowEditModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Edit Course</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form.Group className="mb-3">
            <Form.Label>Course Name</Form.Label>
            <Form.Control value={editValue} onChange={(e) => setEditValue(e.target.value)} autoFocus />
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Change Image (Optional)</Form.Label>
            <Form.Control type="file" accept="image/*" onChange={handleEditImageChange} />
            {editImagePreview && (
              <Image src={editImagePreview} fluid rounded className="mt-3" style={{ maxHeight: "220px" }} />
            )}
          </Form.Group>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowEditModal(false)}>Cancel</Button>
          <Button variant="primary" onClick={saveEdit}>Save Changes</Button>
        </Modal.Footer>
      </Modal>

      {/* Delete Modal */}
      <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)} centered>
        <Modal.Header closeButton className="bg-danger text-white">
          <Modal.Title>Confirm Delete</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Are you sure you want to delete <strong>"{courses[deleteIndex]?.name}"</strong>?
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>Cancel</Button>
          <Button variant="danger" onClick={confirmDelete}>Yes, Delete</Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
}